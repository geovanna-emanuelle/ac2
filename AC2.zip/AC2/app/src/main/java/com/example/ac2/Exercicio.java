package com.example.ac2;

import android.os.Parcel;
import android.os.Parcelable;

public class Exercicio implements Parcelable {
    private String nome;
    private int duracao;

    public Exercicio(String nome, int duracao) {
        this.nome = nome;
        this.duracao = duracao;
    }

    protected Exercicio(Parcel in) {
        nome = in.readString();
        duracao = in.readInt();
    }

    public static final Creator<Exercicio> CREATOR = new Creator<Exercicio>() {
        @Override
        public Exercicio createFromParcel(Parcel in) {
            return new Exercicio(in);
        }

        @Override
        public Exercicio[] newArray(int size) {
            return new Exercicio[size];
        }
    };

    public String getNome() {
        return nome;
    }

    public int getDuracao() {
        return duracao;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nome);
        dest.writeInt(duracao);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public String toString() {
        return nome + " - " + duracao + "s";
    }


}
