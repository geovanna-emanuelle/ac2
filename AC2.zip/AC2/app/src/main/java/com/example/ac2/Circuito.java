package com.example.ac2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Circuito extends AppCompatActivity {

    EditText editTextNome, editTextDuracao;
    Button btnCadastrarExercicio, btnIrParaOTreino;
    private ArrayList<Exercicio> listaDeExercicios = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_circuito);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editTextNome = findViewById(R.id.editTextNome);
        editTextDuracao = findViewById(R.id.editTextDuracao);
        btnCadastrarExercicio = findViewById(R.id.btnCadastrarExercicio);
        btnIrParaOTreino = findViewById(R.id.btnIrParaOTreino);

//        btnCadastrarExercicio.setOnClickListener(v -> {
//            String inputNome = editTextNome.getText().toString();
//            int inputDuracao = Integer.parseInt(editTextDuracao.getText().toString());
//
//            if (!inputNome.isEmpty() && inputDuracao > 0) {
//                Circuito exercicio = new Circuito(inputNome, inputDuracao);
//                listaDeExercicios.add(exercicio);
//
//                editTextNome.setText("");
//                editTextDuracao.setText("");
//            }
//        });
        btnCadastrarExercicio.setOnClickListener(v -> cadastrarExercicio());
        btnIrParaOTreino.setOnClickListener(v -> irParaOTreino());

    }

    private void cadastrarExercicio() {
        String nome = editTextNome.getText().toString();
        String imputDuracao = editTextDuracao.getText().toString();

        if (nome.isEmpty() || imputDuracao.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }

        int duracao = Integer.parseInt(imputDuracao);

        Exercicio novoExercicio = new Exercicio(nome, duracao);
        listaDeExercicios.add(novoExercicio);

        editTextNome.setText("");
        editTextDuracao.setText("");
        Toast.makeText(this, "Exercicio cadastrado com sucesso!", Toast.LENGTH_SHORT).show();
    }

    private void irParaOTreino() {
        Intent intent = new Intent(Circuito.this, MainActivity.class);
        intent.putParcelableArrayListExtra("EXERCICIOS_LISTA", listaDeExercicios);
        startActivity(intent);
    }

}